# Sprite Classes for Pygame Template
import pygame as pg
from settings import *
